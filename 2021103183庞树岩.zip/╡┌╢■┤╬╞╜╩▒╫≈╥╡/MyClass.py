
class MyClass(object):
    classVar=456

    def __init__(self,index):
        self.menVar = index
        self.menlist = list()


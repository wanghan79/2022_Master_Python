class dataFatory(object):
    """
    工厂类
    """
    def __init__(self):
        self.__name = "dataFatory"

    def sampling(self, **kwargs):
        raise "This is a base fatory"
